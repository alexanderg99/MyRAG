"use client";

import { useState, useCallback } from "react";
import { v4 as uuidv4 } from "uuid";
import { queryRag, fetchDocuments } from "@/lib/api";
import ChatWindow from "@/components/ChatWindow";
import ChatInput from "@/components/ChatInput";
import type { ChatMessage } from "@/types";
import { useEffect } from "react";

export default function ChatPage() {
  const [messages, setMessages]   = useState<ChatMessage[]>([]);
  const [loading, setLoading]     = useState(false);
  const [docCount, setDocCount]   = useState<number | null>(null);

  // Show how many documents are loaded
  useEffect(() => {
    fetchDocuments()
      .then((docs) => setDocCount(docs.length))
      .catch(() => setDocCount(0));
  }, []);

  const handleSubmit = useCallback(async (question: string) => {
    // Add user message immediately
    const userMsg: ChatMessage = {
      id: uuidv4(),
      role: "user",
      content: question,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);

    try {
      const { answer, sources } = await queryRag(question);
      const assistantMsg: ChatMessage = {
        id: uuidv4(),
        role: "assistant",
        content: answer,
        sources,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      const errorMsg: ChatMessage = {
        id: uuidv4(),
        role: "assistant",
        content: "Something went wrong. Please check the backend is running.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  }, []);

  return (
    <div className="flex flex-col h-[calc(100vh-10rem)] max-w-3xl">

      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-serif text-2xl text-slate-100">Chat</h1>
          <p className="text-slate-500 text-xs font-mono mt-0.5">
            {docCount === null
              ? "Loading documents…"
              : docCount === 0
              ? "No documents ingested yet"
              : `${docCount} document${docCount === 1 ? "" : "s"} available`
            }
          </p>
        </div>

        {messages.length > 0 && (
          <button
            onClick={() => setMessages([])}
            className="text-xs font-mono text-slate-600 hover:text-slate-400 transition-colors"
          >
            Clear chat
          </button>
        )}
      </div>

      {/* Messages */}
      <ChatWindow messages={messages} loading={loading} />

      {/* Input */}
      <div className="mt-4">
        <ChatInput onSubmit={handleSubmit} disabled={loading} />
        <p className="text-slate-700 text-xs font-mono text-center mt-2">
          Enter to send · Shift+Enter for new line
        </p>
      </div>

    </div>
  );
}
