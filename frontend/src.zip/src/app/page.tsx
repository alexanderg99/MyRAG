import Link from "next/link";
import { Upload, MessageSquare, ArrowRight } from "lucide-react";

export default function Home() {
  return (
    <div className="flex flex-col gap-16 pt-8">

      {/* Hero */}
      <div className="space-y-4 max-w-xl">
        <p className="text-amber-400 font-mono text-xs tracking-widest uppercase">
          Local RAG System
        </p>
        <h1 className="font-serif text-4xl leading-tight text-slate-100">
          Chat with your<br />documents.
        </h1>
        <p className="text-slate-400 text-sm leading-relaxed">
          Upload PDFs, ingest them into a local vector database,
          and ask questions. Everything runs on your machine —
          no cloud, no API keys.
        </p>
      </div>

      {/* Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Link
          href="/upload"
          className="group border border-slate-700 hover:border-amber-400/40 rounded-xl p-6 bg-slate-800/40 hover:bg-slate-800/70 transition-all duration-200"
        >
          <div className="flex items-start justify-between mb-4">
            <div className="p-2 rounded-lg bg-amber-400/10 border border-amber-400/20">
              <Upload className="w-5 h-5 text-amber-400" />
            </div>
            <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-amber-400 group-hover:translate-x-0.5 transition-all" />
          </div>
          <h2 className="font-serif text-lg text-slate-100 mb-1">Upload</h2>
          <p className="text-slate-500 text-sm">
            Add PDF documents and run the ingestion pipeline.
          </p>
        </Link>

        <Link
          href="/chat"
          className="group border border-slate-700 hover:border-amber-400/40 rounded-xl p-6 bg-slate-800/40 hover:bg-slate-800/70 transition-all duration-200"
        >
          <div className="flex items-start justify-between mb-4">
            <div className="p-2 rounded-lg bg-amber-400/10 border border-amber-400/20">
              <MessageSquare className="w-5 h-5 text-amber-400" />
            </div>
            <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-amber-400 group-hover:translate-x-0.5 transition-all" />
          </div>
          <h2 className="font-serif text-lg text-slate-100 mb-1">Chat</h2>
          <p className="text-slate-500 text-sm">
            Ask questions and get answers with source citations.
          </p>
        </Link>
      </div>

    </div>
  );
}
